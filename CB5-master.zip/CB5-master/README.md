# CB5
Computer Vision "egg salad" ....
FULL STEAM AHEAD
# Todo
1. Make it work
2. Vision
3. ??
4. Profit
